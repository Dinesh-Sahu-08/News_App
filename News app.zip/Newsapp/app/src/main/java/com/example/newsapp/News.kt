package com.example.newsapp

data class News(val author: String, val title: String, val url: String, val imageUrl: String)